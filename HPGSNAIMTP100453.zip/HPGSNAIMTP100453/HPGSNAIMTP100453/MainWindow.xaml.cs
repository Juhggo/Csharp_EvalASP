﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HPGSNAIMTP100453
{
    //Travail de Guillaume Sauvé et Hugo Patry
    public partial class MainWindow : Window
    {
        private List<Commande> AfficherCommande(int employeID)
        {
            using (EvaluationTP1Entities entityBDD = new EvaluationTP1Entities())
            {
                //listViewClients.ItemsSource = bd.Clients.ToList();
                var query = from Commande in entityBDD.Commandes where employeID == Commande.EmployeID select Commande;
                return query.ToList();
            }
        }
        string databasePath = @"data source=(LocalDB)\MSSQLLocalDB;attachdbfilename=C:\Users\guill\Desktop\school\VS STUDIO\HP_GS_TP1-Naim00453\HP_GS_TP1-Naim00453\EvaluationTP1.mdf";

        SqlConnection connection = null;

        //Liste Clients stocker en C#
        ObservableCollection<Employe> listEmployes;
        public MainWindow()
        {
            InitializeComponent();

            using (EvaluationTP1Entities entityBDD = new EvaluationTP1Entities())
            {
                orderList.ItemsSource = entityBDD.Commandes.ToList();
                comboBoxCategories.DataContext = entityBDD.Categories.ToList();
                comboBoxProduits.DataContext = entityBDD.Produits.ToList();
            }
        }

        private void AfficherEmployes()
        {
            using (EvaluationTP1Entities entityBDD = new EvaluationTP1Entities())
            {
                listViewEmployes.ItemsSource = entityBDD.Employes.ToList();
            }
        }

        private void OnLoadEmployes(object sender, RoutedEventArgs e)
        {
            using (EvaluationTP1Entities entityBDD = new EvaluationTP1Entities())
            {
                listViewEmployes.ItemsSource = entityBDD.Employes.ToList();
            }
        }

        public List<Produit> boxProduit { get; set; }
        public List<Category> boxCategorie { get; set; }
        private void bindProduit()
        {
            EvaluationTP1Entities produits = new EvaluationTP1Entities();
            var itemProduits = produits.Produits.ToList();
            boxProduit = itemProduits;
            DataContext = boxProduit;
        }
        private void bindCategorie()
        {
            EvaluationTP1Entities categories = new EvaluationTP1Entities();
            var itemCategories = categories.Categories.ToList();
            boxCategorie = itemCategories;
            DataContext = boxCategorie;
        }
        private void CB_ProduitChanged(object sender, SelectionChangedEventArgs e)
        {
            var item = comboBoxProduits.SelectedItem as Produit;
        }
        private void CB_CategorieChanged(object sender, SelectionChangedEventArgs e)
        {
            var item = comboBoxCategories.SelectedItem as Category;
        }

        private static int employeModif(Employe listEmployes, SqlConnection connection)
        {
            try
            {
                string requete = @"INSERT INTO Employe(EmployeID, Nom, Prenom, Titre, DateDeNaissance, DateEmbauche, Adresse, Province, CodePostal, Pays, Telephone, Extension, Notes)
                                    VALUES(@EmployeID, @Nom, @Prenom, @DateDeNaissance, @DateEmbauche, @Adresse, @Province, @CodePostal, @Pays, @Telephone, @Extension, @Notes);";

                SqlCommand cmd = new SqlCommand(requete, connection);
                cmd.Parameters.AddWithValue("@EmployeID", listEmployes.EmployeID);
                cmd.Parameters.AddWithValue("@Nom", listEmployes.Nom);
                cmd.Parameters.AddWithValue("@Prenom", listEmployes.Prenom);
                cmd.Parameters.AddWithValue("@DateDeNaissance", listEmployes.DateDeNaissance);
                cmd.Parameters.AddWithValue("@Adresse", listEmployes.Adresse);
                cmd.Parameters.AddWithValue("@Province", listEmployes.Province);
                cmd.Parameters.AddWithValue("@CodePostal", listEmployes.CodePostal);
                cmd.Parameters.AddWithValue("@Pays", listEmployes.Pays);
                cmd.Parameters.AddWithValue("@Telephone", listEmployes.Telephone);
                cmd.Parameters.AddWithValue("@Extension", listEmployes.Extension);
                cmd.Parameters.AddWithValue("@Notes", listEmployes.Notes);

                return cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }

        private void btnEffacer_Click(object sender, RoutedEventArgs e)
        {
            textBoxNom.Text = "";
            textBoxPrenom.Text = "";
            textBoxTitre.Text = "";
            boxDateNaissance.SelectedDate = null;
            boxDateEmbauche.SelectedDate = null;
            textBoxAdresse.Text = "";
            textBoxProvince.Text = "";
            textBoxCodePostal.Text = "";
            textBoxPays.Text = "";
            textBoxTelephone.Text = "";
            textExtension.Text = "";
            textBoxNotes.Text = "";
            comboBoxCategories.SelectedIndex = -1;
            comboBoxProduits.SelectedIndex = -1;
        }

        private void btnSauvegarder_Click(object sender, RoutedEventArgs e)
        {
            Employe employe = new Employe
            {
                Nom = textBoxNom.Text,
                Prenom = textBoxPrenom.Text,
                Titre = textBoxTitre.Text,
                DateDeNaissance = boxDateNaissance.SelectedDate.Value,
                DateEmbauche = boxDateEmbauche.SelectedDate.Value,
                Adresse = textBoxAdresse.Text,
                Province = textBoxProvince.Text,
                CodePostal = textBoxCodePostal.Text,
                Pays = textBoxPays.Text,
                Telephone = textBoxTelephone.Text,
                Extension = textExtension.Text,
                Notes = textBoxNotes.Text
            };
            using (EvaluationTP1Entities entityBDD = new EvaluationTP1Entities())
            {
                if (listEmployes != null)
                {
                    entityBDD.Employes.Add(employe);
                    int resultat = entityBDD.SaveChanges();
                    if (resultat > 0)
                    {
                        AfficherEmployes();
                    }
                }
            }
        }

        private void btnQuitter_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void btnModifier_Click(object sender, RoutedEventArgs e)
        {
            Employe employeClick = listViewEmployes.SelectedItem as Employe;
            if (employeClick != null)
            {
                using (EvaluationTP1Entities entityBDD = new EvaluationTP1Entities())
                {
                    Employe employeModif = entityBDD.Employes.FirstOrDefault(x => x.EmployeID == employeClick.EmployeID);
                    if (employeModif != null)
                    {
                        employeModif.Nom = textBoxNom.Text;
                        employeModif.Prenom = textBoxPrenom.Text;
                        employeModif.DateDeNaissance = boxDateNaissance.SelectedDate.Value;
                        employeModif.Adresse = textBoxAdresse.Text;
                        employeModif.Telephone = textBoxTelephone.Text;
                        employeModif.Extension = textExtension.Text;
                        employeModif.Notes = textBoxNotes.Text;

                        int resultat = entityBDD.SaveChanges();
                        if (resultat > 0)
                            AfficherEmployes();
                    }
                }
            }
        }

        /*(Modification du script SQL pour pouvoir effacer un employé, les commentaires sont un essai d'effacer la commande avant d'effacer l'employe
          mais les restrictions du script sql rendait la tâche difficile.
            CREATE TABLE "Commandes"(
	        "CommandeID" INTEGER PRIMARY KEY,
	        "ClientID" nchar (5) NULL ,
	        "EmployeID" "int" NULL ,
	        "DateCommande" "datetime" NULL ,
	        "DateRequise" "datetime" NULL ,
	        "DateEnvoi" "datetime" NULL ,
	        "AdresseEnvoi" nvarchar (60) NULL ,
	        "VilleEnvoi" nvarchar (15) NULL ,
	        "CodePostalEnvoi" nvarchar (10) NULL ,
	        "PaysEnvoi" nvarchar (15) NULL
	        );
	        ALTER TABLE [dbo].[Commandes] WITH CHECK ADD CONSTRAINT [FK_Commandes_Employe] FOREIGN KEY ([EmployeID])
	        REFERENCES [dbo].[Employes] ([EmployeID]) ON DELETE CASCADE;
	        ALTER TABLE [dbo].[Commandes] WITH CHECK ADD CONSTRAINT [FK_Commandes_Client] FOREIGN KEY ([ClientID])
	        REFERENCES [dbo].[Clients] ([ClientID]) ON DELETE CASCADE;
            */

        private void btnSupprimer_Click(object sender, RoutedEventArgs e)
        {
            Employe employeSelectionne = listViewEmployes.SelectedItem as Employe;
            //Commande commandeSelectionne = listViewCommandes.SelectedItem as Commande;

            if (employeSelectionne != null)
            {
                using (EvaluationTP1Entities entityBDD = new EvaluationTP1Entities())
                {
                    Employe empSupprime = entityBDD.Employes.SingleOrDefault(emp => emp.EmployeID == employeSelectionne.EmployeID);
                    //Commande commandeSupprime = entityBDD.Commandes.SingleOrDefault(commande => commande.CommandeID == commandeSelectionne.CommandeID);
                    if (empSupprime != null)
                    {
                        //entityBDD.Commandes.Remove(commandeSupprime);
                        //int resultat = entityBDD.SaveChanges();
                        entityBDD.Employes.Remove(empSupprime);
                        int resultat = entityBDD.SaveChanges();
                        if (resultat > 0)
                        {
                            AfficherEmployes();
                        }
                    }
                }
            }
        }

        private void orderList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Commande commandeClient = ((Commande)orderList.SelectedItem);
            ListeClients pageListeClients = new ListeClients(commandeClient.CommandeID);
            orderList.Visibility = Visibility.Hidden;
            pageFrame.Content = pageListeClients;
        }

        private void listViewEmployes_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Employe commandeEmploye = ((Employe)listViewEmployes.SelectedItem);
            orderList.ItemsSource = AfficherCommande(commandeEmploye.EmployeID);
        }
    }
}
