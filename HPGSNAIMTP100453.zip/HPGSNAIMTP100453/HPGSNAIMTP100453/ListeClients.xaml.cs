﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity;
using System.Data.Entity.Migrations;

namespace HPGSNAIMTP100453
{
    //Travail de Guillaume Sauvé et Hugo Patry
    public partial class ListeClients : Page
    {
        private List<Client> AfficherClients(int commandeID)
        {
            using (EvaluationTP1Entities entityBDD = new EvaluationTP1Entities())
            {
                //listViewClients.ItemsSource = bd.Clients.ToList();
                Commande commandeClient = entityBDD.Commandes.ToList().SingleOrDefault(c => c.CommandeID == commandeID);
                var query = from Client in entityBDD.Clients where commandeClient.ClientID == Client.ClientID select Client;
                return query.ToList();
            }
        }

        public ListeClients(int commandeID)
        {
            InitializeComponent();
            listViewClients.ItemsSource = AfficherClients(commandeID);
        }

        internal bool? clickviewClients(Client listClients, Commande listCommande, SqlConnection connection)
        {
            //Essai de convertir la requete SQL en code c# entity framework
            Client ClientSelectionne = listViewClients.SelectedItem as Client;
            //Commande commandeSelectionne = listViewCommandes.SelectedItem as Commande;
            if (ClientSelectionne != null)
            {
                using (EvaluationTP1Entities entityBDD = new EvaluationTP1Entities())
                {
                    listViewClients.ItemsSource = entityBDD.Clients.ToList();
                }
            }
                try
            {
                string requete = @"WHERE Client.ClientID == Commande.ClientID, SELECT FROM * Client(NomCompagnie, NomContact, TitreContact, Adresse, CodePostal, Pays, Telephone, Fax),
                                    VALUES(@NomCompagnie, @NomContact, @TitreContact, @Adresse, @Province, @CodePostal, @Pays, @Telephone, @Fax);";

                SqlCommand cmd = new SqlCommand(requete, connection);
                cmd.Parameters.AddWithValue("@NomCompagnie", listClients.NomCompagnie);
                cmd.Parameters.AddWithValue(@"NomContact", listClients.NomContact);
                cmd.Parameters.AddWithValue(@"TitreContact", listClients.TitreContact);
                cmd.Parameters.AddWithValue(@"Adresse", listClients.Adresse);
                cmd.Parameters.AddWithValue(@"Province", listClients.Province);
                cmd.Parameters.AddWithValue(@"CodePostal", listClients.CodePostal); ;
                cmd.Parameters.AddWithValue(@"Pays", listClients.Pays);
                cmd.Parameters.AddWithValue(@"Telephone", listClients.Telephone);
                cmd.Parameters.AddWithValue(@"Fax", listClients.Fax);
                cmd.ExecuteNonQuery();

                using (EvaluationTP1Entities entityBDD = new EvaluationTP1Entities())
                {
                    listViewClients.ItemsSource = entityBDD.Clients.ToList();
                }
                return false;
            }
            catch (Exception ex)
            {
                throw new Exception();
            }
        }
        internal bool? clickviewClients()
        {
            throw new NotImplementedException();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ((MainWindow)Window.GetWindow(this)).pageFrame.Content = null;
            ((MainWindow)Window.GetWindow(this)).orderList.Visibility = Visibility.Visible;
        }
    }
}
