﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HPGSNAIMTP100453
{
    internal class ListViews
    {
        public class listClients
        {
            public int ClientID { get; set; }
            public string NomCompagnie { get; set; }
            public string NomContact { get; set; }
            public string TitreContact { get; set; }
            public string Adresse { get; set; }
            public string Province { get; set; }
            public string CodePostal { get; set; }
            public string Pays { get; set; }
            public string Telephone { get; set; }
            public string Fax { get; set; }
        }

        public class listEmployes
        {
            public int EmployeID { get; set; }
            public string Nom { get; set; }
            public string Prenom { get; set; }
            public string Titre { get; set; }
            public DateTime DateDeNaissance { get; set; }
            public DateTime DateEmbauche { get; set; }
            public string Adresse { get; set; }
            public string Province { get; set; }
            public string CodePostal { get; set; }
            public string Pays { get; set; }
            public string Telephone { get; set; }
            public string Extension { get; set; }
            public string Notes { get; set; }
        }

        public class listCommandes
        {
            public int CommandeID { get; set; }
            public int ClientID { get; set; }
            public int EmployeID { get; set; }
            public DateTime DateCommande { get; set; }
            public DateTime DateRequise { get; set; }
            public DateTime DateEnvoi { get; set; }
            public string VilleEnvoi { get; set; }
            public string CodePostalEnvoi { get; set; }
            public string PaysEnvoi { get; set; }
        }
    }
}
